Please run my code "section by section"
I made it easy to understand my code when you go through section by section

Main File  : "Predictive_Kwon"
Data Fiile : "ai4i2020.csv"
Function Files
	For Naive Bayes
		: "MultiNaiveBayes.m"		(Creates Model & Classify Data)
	For Decision Tree
		: "MultiDecisionTree.m"		(Creates Model)
		: "ClassifyDecisionTree.m"	(Classify Data)
		: "PrintDecisionTree.m"		(Prints Model)
	For K-Nearest Neighbor
		: "MultiKNN.m"			(Creates Model & Classify Data)
	For Logistic Regression
		: "MultiLRG.m"			(Creates Model & Classify Data)
	For PCA
		: "PCA.m"				(Creates Principal Components)
	
Thanks,
June K.